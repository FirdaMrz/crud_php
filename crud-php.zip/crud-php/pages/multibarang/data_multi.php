<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      DATA PENJUALAN MULTI ITEM
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> HOME</a></li>
        <li class="active">DATA PENJUALAN MULTI ITEM</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
      <div class="box box-primary">
        <div class="box-header">
          <a href="index.php?page=data_multibarang" class="btn btn-primary" role="button" title="Tambah Data"><i class="glyphicon glyphicon-plus"></i> Tambah Data</a>
          <a href="pages/report.php" class="btn btn-warning" role="button" title="Print"><i class="glyphicon glyphicon-print"></i> Print</a>
          </div>
            <div class="box-body table-responsive">
              <table id="detail_jual" class="table table-bordered table-hover">
                <thead>
                <tr>
                  
                  <th>ID</th>
                  <th>TANGGAL</th>
                  <th>PEGAWAI</th>
                  <th>TOTAL</th>
                  <th>AKSI</th>
                </tr>
                </thead>
                <tbody>

                <?php
                include "conf/conn.php";
                $no=0;
                
                $query=mysqli_query($koneksi,"SELECT * FROM jual")
                or die(mysqli_error($koneksi));
                while ($row=mysqli_fetch_array($query))
                {

                ?>
                <tr>
                  <td><?php echo $no=$no+1;?></td>
                  <td><?php echo $row['id'];?></td>
                  <td><?php echo $row['tgl'];?></td>
                  <td><?php echo $row['pegawai'];?></td>
                  <td><?php echo $row['total'];?></td>
                  <td>
                  <a href="index.php?page=data_singleitem&id=<?=$row['id'];?>" class="btn btn-success" role="button" title="Detail"><i class="glyphicon glyphicon-edit"></i></a>
                  <a href="pages/report2.php?id=<?=$row['id']?>" class="btn btn-warning" role="button" title="Print"><i class="glyphicon glyphicon-print"></i> Print</a>
                </tr>

                <?php } ?>

                </tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
<!-- /.content-wrapper -->

<!-- Javascript Datatable -->
<script type="text/javascript">
  $(document).ready(function(){
    $('#mahasiswa').DataTable();
  });
</script>