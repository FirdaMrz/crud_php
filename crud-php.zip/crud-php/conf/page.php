<?php
if(isset($_GET['page'])){
  $page = $_GET['page'];
switch ($page) {
// Beranda
//mahasiswa//
  case 'data_mahasiswa':
    include 'pages/mahasiswa/data_mahasiswa.php';
    break;

    case 'tambah_mahasiswa':
include 'pages/mahasiswa/tambah_mahasiswa.php';
break;

case 'ubah_mahasiswa';
include 'pages/mahasiswa/ubah_mahasiswa.php';
break;

//databarang//
case 'data_databarang';
include 'pages/databarang/data_databarang.php';
break;

case 'tambah_barang':
  include 'pages/databarang/tambah_barang.php';
  break;

  case 'ubah_barang';
include 'pages/databarang/ubah_barang.php';
break;

//barang//
case 'data_barang';
include 'pages/barang/transaksi_barang.php';
break;

//multibarang//
case 'data_multibarang':
  include 'pages/multibarang/data_transaksi_barang.php';
  break;

case 'bayar':
  include 'pages/multibarang/bayar.php';
  break;

//single-item//
case 'data_singleitem':
  include 'pages/multibarang/data_single.php';
  break;

//multi-item//
case 'data_multiitem':
  include 'pages/multibarang/data_multi.php';
  break;
  
  }
}else{
    include "pages/beranda.php";
  }
?>